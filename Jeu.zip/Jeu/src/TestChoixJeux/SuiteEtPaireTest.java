package TestChoixJeux;

import static org.junit.Assert.*;

import java.util.ArrayList;

import javax.swing.JButton;

import org.junit.Test;
import ChoixJeux.SuiteEtPaire;

public class SuiteEtPaireTest {

	@Test
	public void testAjoutElementListe() {
		SuiteEtPaire paire =new SuiteEtPaire();
		paire.ajoutElementListe();
	    assertEquals(8, paire.getCaseOrdi().size());
	}

	@Test
	public void testComparePaire() {
		SuiteEtPaire paire =new SuiteEtPaire();
		JButton btn3 = new JButton("Bleu");
		JButton btn4 = new JButton("Jaune");
		ArrayList<JButton> compareBout = new ArrayList<JButton>();
		compareBout.add(btn3);
		compareBout.add(btn4);
	    assertEquals(false, paire.comparePaire(compareBout));
	    compareBout.removeAll(compareBout);
	    compareBout.add(btn3);
		compareBout.add(btn3);
	    assertEquals(true, paire.comparePaire(compareBout));
	}

	@Test
	public void testAjoutElementListeSuite() {
		SuiteEtPaire suite =new SuiteEtPaire();
		suite.ajoutElementListeSuite();
	    assertEquals(4, suite.getCaseOrdiCouleur().size());
		suite.ajoutElementListeSuite();
	    assertEquals(5, suite.getCaseOrdiCouleur().size());
		suite.ajoutElementListeSuite();
	    assertEquals(6, suite.getCaseOrdiCouleur().size());
	}

	@Test
	public void testCompareSuite() {
		SuiteEtPaire suite =new SuiteEtPaire();
		suite.ajoutElementListeSuite();
		ArrayList<String> suiteElem = new ArrayList<String>();
		suiteElem.add("Bleu");
		suiteElem.add("Vert");
		suiteElem.add("Noire");
		suiteElem.add("Rouge");
		String elem = suite.compareSuite(suiteElem);
		assertEquals("Echec", elem);
		
		suite.ajoutElementListeSuite();
		String elem2 = suite.compareSuite(suite.getCaseOrdiCouleur());
		assertEquals("Suite exacte", elem2);
	}

}
