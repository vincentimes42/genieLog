package ChoixJeux;
import java.util.ArrayList;

import javax.swing.JButton;

public class SuiteEtPaire {
	private ArrayList<String> caseOrdi;
	private ArrayList<String> lesCases;
	private ArrayList<String> caseOrdiCouleur;
	private ArrayList<String> couleur;
	
	public SuiteEtPaire(){
		this.caseOrdi = new ArrayList<String>();
		this.lesCases = new ArrayList<String>();
		this.caseOrdiCouleur = new ArrayList<String>();
		this.couleur = new ArrayList<String>();
		
		lesCases.add("AS");
		lesCases.add("Roi");
		lesCases.add("Reine");
		lesCases.add("Valet");

		couleur.add("Rouge");
		couleur.add("Vert");
		couleur.add("Bleu");
		couleur.add("Jaune");
	}

	public void ajoutElementListe(){
		int min=0,max=4,i=0;
		int id0=0,id1=0,id2=0,id3=0;
		while(i<8){
			int valeur =min+(int)(Math.random()*((max - min)));
			if(valeur == 0 && id0<2){
				caseOrdi.add(lesCases.get(valeur));
				id0++;
				i++;
			}else if(valeur == 1 && id1<2){
				caseOrdi.add(lesCases.get(valeur));
				id1++;
				i++;
			}else if(valeur == 2 && id2<2){
				caseOrdi.add(lesCases.get(valeur));
				id2++;
				i++;				
			}else if(valeur == 3 && id3<2){
				caseOrdi.add(lesCases.get(valeur));
				id3++;
				i++;
			}
		}
	}
	
	public boolean comparePaire(ArrayList<JButton> list){
		boolean rep = false;
		
		if(list.get(0).getText()==list.get(1).getText()){
			rep = true;
		}		
		return rep;
	}
	
	public void ajoutElementListeSuite(){
		int min=0,max=4;
		if(caseOrdiCouleur.size()==0){
			for(int i=0; i<4; i++){
				caseOrdiCouleur.add(couleur.get(min+(int)(Math.random()*((max - min)))));
			}
		}else{
			caseOrdiCouleur.add(couleur.get(min+(int)(Math.random()*((max - min)))));
		}
	}
	
	public String compareSuite(ArrayList<String> list){
		boolean rep = false;
		String reponse="";
		for(int i=0; i<caseOrdiCouleur.size(); i++){
			if(caseOrdiCouleur.equals(list)){
				rep = true;
			}
		}
		if(rep==true){
			reponse="Suite exacte";
			ajoutElementListeSuite();
		}else{
			reponse="Echec";
			caseOrdiCouleur.removeAll(caseOrdiCouleur);
		}
		return reponse;
	}

	public ArrayList<String> getCaseOrdi(){
		return this.caseOrdi;
	}
	
	public ArrayList<String> getCaseOrdiCouleur(){
		return this.caseOrdiCouleur;
	}
}
