package ChoixJeux;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Color;

public class Simon extends JFrame  implements ActionListener{
	
	private JLabel Simon = new JLabel("SIMON");
	private JLabel Resultat = new JLabel("Vous avez :");
	private JButton btn1 = new JButton("Rouge");
	private JButton btn2 = new JButton("Vert");
	private JButton btn3 = new JButton("Bleu");
	private JButton btn4 = new JButton("Jaune");
	
	private SuiteEtPaire uneSuite = new SuiteEtPaire();
	private ArrayList<String> caseJoueur = new ArrayList<String>();
	private int lvl = 1, compt = 0;
	private boolean win = true;
	
	public Simon() throws InterruptedException{
		Simon.setHorizontalAlignment(SwingConstants.CENTER);
		Resultat.setHorizontalAlignment(SwingConstants.CENTER);
	    this.setTitle("Simon");
	    this.setSize(500, 500);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);

	    JPanel simon = new JPanel();
	    simon.setLayout(new GridLayout(2, 2));
	    simon.add(btn1);
	    simon.add(btn2);
	    simon.add(btn3);
	    simon.add(btn4);
	    	    
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(Simon, BorderLayout.NORTH);
	    this.getContentPane().add(simon, BorderLayout.CENTER);
	    this.getContentPane().add(Resultat, BorderLayout.SOUTH);

		uneSuite.ajoutElementListe();
		
		btn1.setBackground(Color.RED);
		btn2.setBackground(Color.GREEN);
		btn3.setBackground(Color.BLUE);
		btn4.setBackground(Color.YELLOW);
		
    	btn1.addActionListener(this);
	    btn2.addActionListener(this);
	    btn3.addActionListener(this);
	    btn4.addActionListener(this);
	    this.setVisible(true);

    	this.serie(uneSuite.getCaseOrdiCouleur());
	    int t = 5;
	    while(win){
			for (int i = t; i >= 0; i--){
				Simon.setText("Simon -- "+i+" sec --");
				Thread.sleep(1000);
			}
			if(lvl>=10){t++;}
		    if(win && caseJoueur.size()==uneSuite.getCaseOrdiCouleur().size()-1){
		    	caseJoueur = new ArrayList<String>();
		    	lvl++;
		    	this.serie(uneSuite.getCaseOrdiCouleur());
		    }
	    }
	    this.dispose();
	}
	
	public void btnEnable(Boolean able){
		 btn1.setEnabled(able);
		 btn2.setEnabled(able);
		 btn3.setEnabled(able);
		 btn4.setEnabled(able);
	}
	
	public void serie(ArrayList<String> list) throws InterruptedException{
		btnEnable(false);
		boolean condit1=false,condit2=false,condit3=false,condit4=false;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) == "Rouge") {
				if(i>0 && list.get(i-1) == "Rouge" && condit1){btn1.setBackground(Color.GRAY);condit1=condit2=condit3=condit4=false;}
				else if(!condit1){btn1.setBackground(Color.BLACK);condit1=true;condit2=condit3=condit4=false;}
				try {
					Thread.sleep(1000);
					btn1.setBackground(Color.RED);
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}else if (list.get(i) == "Vert"){
				if(i>0 && list.get(i-1) == "Vert"&& condit2){btn2.setBackground(Color.GRAY);condit1=condit2=condit3=condit4=false;}
				else if(!condit2){btn2.setBackground(Color.BLACK);condit2=true;condit1=condit3=condit4=false;}
				try {
					Thread.sleep(1000);
					btn2.setBackground(Color.GREEN);
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}else if (list.get(i) == "Bleu"){
				if(i>0 && list.get(i-1) == "Bleu"&& condit3){btn3.setBackground(Color.GRAY);condit1=condit2=condit3=condit4=false;}
				else if(!condit3){btn3.setBackground(Color.BLACK);condit3=true;condit1=condit2=condit4=false;}
				try {
					Thread.sleep(1000);
					btn3.setBackground(Color.BLUE);
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}else if (list.get(i) == "Jaune") {
				if(i>0 && list.get(i-1) == "Jaune"&& condit4){btn4.setBackground(Color.GRAY);condit1=condit2=condit3=condit4=false;}
				else if(!condit4){btn4.setBackground(Color.BLACK);condit4=true;condit1=condit2=condit3=false;}
				try {
					Thread.sleep(1000);
					btn4.setBackground(Color.YELLOW);
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		btnEnable(true);
	}
	
	public void actionPerformed(ActionEvent arg0) {
		
		JButton btn = (JButton) arg0.getSource();
		if(btn.getText()=="Rouge"){caseJoueur.add("Rouge");}
		else if(btn.getText()=="Vert"){caseJoueur.add("Vert");}
		else if(btn.getText()=="Bleu"){caseJoueur.add("Bleu");}
		else if(btn.getText()=="Jaune"){caseJoueur.add("Jaune");}
		
		String reponse;
		compt++;
		
		if(compt==uneSuite.getCaseOrdiCouleur().size()){
			reponse = uneSuite.compareSuite(caseJoueur);
			
			compt=0;
			Resultat.setText("Vous avez : "+ reponse);
		    if(reponse=="Echec"){
		    	win=false;
		    }
		}
	}
}
