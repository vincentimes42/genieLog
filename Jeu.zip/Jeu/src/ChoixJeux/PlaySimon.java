package ChoixJeux;

public class PlaySimon implements Runnable {
    Simon unSimon;
    
	public void run(){
		try {
			unSimon = new Simon();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}
