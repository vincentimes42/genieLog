package ChoixJeux;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ChoixJeux  extends JFrame  implements ActionListener{
	
	private JLabel Titre = new JLabel("Choisissez votre jeu :");
	private JButton Simon = new JButton("Simon");
	private JButton Memory = new JButton("Memory");
	private JButton JeuDeLoie = new JButton("JeuDeLoie");
	private Thread t;
	
	public ChoixJeux(){
		this.setTitle("Mini Jeux");
		this.setSize(500, 500);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
	    
	    JPanel miniJeu = new JPanel();
	    miniJeu.setLayout(new GridLayout(3, 1));
	    miniJeu.add(Simon);
	    miniJeu.add(Memory);
	    miniJeu.add(JeuDeLoie);
	    
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(Titre, BorderLayout.NORTH);
	    this.getContentPane().add(miniJeu, BorderLayout.CENTER);
	    
	    Simon.setBackground(Color.RED);
	    Memory.setBackground(Color.GREEN);
	    JeuDeLoie.setBackground(Color.BLUE);
	    
	    Simon.addActionListener(this);
	    Memory.addActionListener(this);
	    JeuDeLoie.addActionListener(this);
	    
	    this.setVisible(true);
	    
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0){
		
		JButton btn = (JButton) arg0.getSource();
		if(btn.getText()=="Simon"){
			t = new Thread(new PlaySimon());
		    t.start();
		}else if(btn.getText()=="Memory"){
			t = new Thread(new PlayMemory());
		    t.start();
		}else if(btn.getText()=="JeuDeLoie"){
			boolean Tour;
			Plateau P= new Plateau();
			P.creerPlateauClassique();
			P.getListeCase();
			LinkedList lj = new LinkedList();
			Scanner scan = new Scanner(System.in);
			System.out.println("Veuillez saisir le nombre de joueurs : ");
			int nb = scan.nextInt();
			System.out.println(nb+ " joueur(s)");
			for(int i = 0; i< nb ; i++) {
				Scanner sc = new Scanner(System.in);
				System.out.println("Veuillez saisir un nom de joueur :");
				String str = sc.nextLine();
				System.out.println("Vous avez saisi : " + str);
			    lj.add(str);
			}
			P.creerListejoueur(lj);
			Tour=false;
			while (Tour==false){
				Tour=P.Tour();
			}
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		ChoixJeux choix = new ChoixJeux();
	}
}
