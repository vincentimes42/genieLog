package ChoixJeux;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ChoixJeux  extends JFrame  implements ActionListener{
	
	private JLabel Titre = new JLabel("Choisissez votre jeu :");
	private JButton Simon = new JButton("Simon");
	private JButton Memory = new JButton("Memory");
	private Thread t;
	
	public ChoixJeux(){
		this.setTitle("Mini Jeux");
		this.setSize(500, 500);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
	    
	    JPanel miniJeu = new JPanel();
	    miniJeu.setLayout(new GridLayout(2, 1));
	    miniJeu.add(Simon);
	    miniJeu.add(Memory);
	    
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(Titre, BorderLayout.NORTH);
	    this.getContentPane().add(miniJeu, BorderLayout.CENTER);
	    
	    Simon.setBackground(Color.RED);
	    Memory.setBackground(Color.GREEN);
	    
	    Simon.addActionListener(this);
	    Memory.addActionListener(this);
	    
	    this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0){
		
		JButton btn = (JButton) arg0.getSource();
		if(btn.getText()=="Simon"){
			this.dispose();
			t = new Thread(new PlaySimon());
		    t.start();
		}else if(btn.getText()=="Memory"){
			this.dispose();
			t = new Thread(new PlayMemory());
		    t.start();
		}	
	}
	
	public static void main(String[] args) throws InterruptedException {
		ChoixJeux choix = new ChoixJeux();
	}
}
