package jeu_de_l_oie;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ListIterator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AffichagePlateau extends JFrame  implements ActionListener{

	private JButton De1 = new JButton("d� 1");
	private JButton De2 = new JButton("d� 2");
	private JLabel jeuDeLoie = new JLabel("jeu de L'oie :");

	private PartieDeLoie partie= new PartieDeLoie(); 
	private Plateau P= new Plateau();
	
	public AffichagePlateau(int typePlateau) {
		this.setTitle("jeu de l'oie");
		this.setSize(900, 900);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
	    
	    JPanel Plateau = new JPanel();
	    Plateau.setLayout(new GridLayout(8,8,5,1));
	    if (typePlateau==1) P.creerPlateauClassique();
	    if (typePlateau==2)P.creerPlateauAleatoire();
	    ListIterator<Case> lic = P.getListeCase().listIterator(); //cr�ation boutons cases et ajout au panel Plateau
		Case Case ; 
		while(lic.hasNext()) {      //on it�re sur chaque case de la  liste
			Case= lic.next();
		    Plateau.add(partie.affichageCase(Case));
		}
	    
		JPanel PanneauInfo = new JPanel();
	    PanneauInfo.setLayout(new GridLayout(5, 3));
	    PanneauInfo.add(De1);
	    PanneauInfo.add(De2);
	    
		
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(jeuDeLoie, BorderLayout.NORTH);
	    this.getContentPane().add(Plateau, BorderLayout.CENTER);
	    this.getContentPane().add(PanneauInfo, BorderLayout.EAST);
	    
	    
	    De1.addActionListener(this);
	    De2.addActionListener(this);
	    
	    this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		JButton btn = (JButton) arg0.getSource();
		if(btn.getText()=="d� 1") { partie.setWaitDe1(false);}
		else if(btn.getText()=="d� 2") { partie.setWaitDe2(false);}
		
	}
}
