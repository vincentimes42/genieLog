package jeu_de_l_oie;

public class Joueur {

	private int id;
	private String nom;
	private int position;
	private int jetDes;
	private int nbTourBloque;
	private boolean victoire;
	
	//constructeur
	
	public Joueur (int id ,String nom){
		this.id =id;
		this.nom= nom;
		this.position=1;
		this.jetDes=0;
		this.nbTourBloque=0;
		
	}
	
	//accesseur
	public void setNom(String nom){
		this.nom= nom;
	}
	
	public void setId(int id){
		this.id= id;
	}

	public void setPosition(int position) {
		this.position= position;
	
	}
	
	public void setJetdes(int des){
		this.jetDes= des;
	}
	
	public void setBloque(int bloque) {
		this.nbTourBloque=bloque;
	}
	public boolean setVictoire(boolean bool) {
		return this.victoire=bool;
	}
	
	public int getId(){
		return this.id;
	}
	
	public String getNom(){
		return this.nom;
	}
	
	
	
	public int getPosition(){
		return this.position;
	}
	
	public int getJetDes(){
		return this.jetDes;
	}
	
	public int getBloque(){
		return this.nbTourBloque;
	}
	public boolean getVictoire() {
	return this.victoire;
	}
}
