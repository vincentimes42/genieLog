package jeu_de_l_oie;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public static void class main (String[] args) {
	
	private boolean Tour;
	private plateau P= new plateau();
	P.creerPlateauClassique();
	List lj = new LinkedList();
    lj.add("vincent");
    lj.add("toto");
	P.creerListejoueur(lj);
	Tour=false;
	while (Tour==false){
		Tour=P.Tour();
	}
	
		
}
}
