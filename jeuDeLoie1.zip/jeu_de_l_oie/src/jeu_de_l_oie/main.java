package jeu_de_l_oie;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

 class main  {
	public static void  main (String[] args) {
		boolean Tour;
		plateau P= new plateau();
		P.creerPlateauClassique();
		P.getListeCase();
		List lj = new LinkedList();
	    lj.add("vincent");
	    lj.add("toto");
		P.creerListejoueur(lj);
		Tour=false;
		while (Tour==false){
			Tour=P.Tour();
		}
	
		
	}
}
