package jeu_de_l_oie;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

public class plateau {
	
	private LinkedList<Case> listeCase = new LinkedList<Case>();
	private LinkedList<Joueur> listeJoueur = new LinkedList<Joueur>();
	
	
	//cr�ation
	
		
		public void creerPlateauClassique(){
			int tailleListe=listeCase.size();
			if (tailleListe != 0)  throw new IllegalArgumentException("le plateau n'est pas vide"); 
			for(int i = 1; i <= 63; i++) {
				Case Case = new Case(i);
				listeCase.add(Case);
			}
			
		}
	
		public void creerPlateauAleatoire() {
			int tailleListe=listeCase.size();
			if (tailleListe != 0)  throw new IllegalArgumentException("le plateau n'est pas vide"); 
			for(int i = 1; i <= 63; i++) {
				Random r = new Random();
				if (i<13) {	          //on met une limite ici car l'action d'id 42 fait reculer de 12 cases donc il faut au moins 13 cases
				int valeur = 2 + r.nextInt(40);	//on g�n�re al�atoirement l'action de la casse
				Case Case = new Case(i,valeur);
				listeCase.add(Case);
				}
				else if (i>12 && i<63){
					int valeur = 2+ r.nextInt(61);
					Case Case = new Case(i,valeur);
					listeCase.add(Case);
				}
				else {                       // la derni�re case g�n�r�e est toujours celle d'id d'action 63
					Case Case = new Case(i,i);
					listeCase.add(Case);
				}
			}
		
		}
		
		public void creerListejoueur(List<String> listeNom) {
			int tailleListeNom=listeNom.size();
			if (tailleListeNom == 0)  throw new IllegalArgumentException("la listeNom est  vide");
			int tailleListeJoueur=listeJoueur.size();
			if (tailleListeJoueur != 0)  throw new IllegalArgumentException("la listeJoueur n'est pas vide");	
			for(int i = 0; i < tailleListeNom; i++) {
				Joueur joueur = new Joueur(i,listeNom.get(i));
				listeJoueur.add(joueur);
			}
		}
	
	//accesseurs
		
		
		
		public LinkedList<Case> getListeCase(){
			return this.listeCase;
		}
		
		public LinkedList<Joueur> getListeJoueur(){
			return this.listeJoueur;
		}
	
	//fonctions
			
		public Case deplacement ( Joueur joueur) {
			int nb= joueur.getJetDes();
			Case Case;
			if ((nb<-13||nb>63||nb==0||nb==1||nb==-1)) throw new IllegalArgumentException("id pas dans l'interval absolu des d�s");
			if (nb<0) Case=deplacementArri�re(joueur);
			else Case=deplacementAvant(joueur);
			return Case;
		}
		
		private Case deplacementAvant ( Joueur joueur) {
			
		
			int nb= joueur.getJetDes();
			if ((nb<-13||nb>63||nb==0||nb==1||nb==-1)) throw new IllegalArgumentException("id pas dans l'interval absolu des d�s");
			ListIterator<Case> li = listeCase.listIterator(joueur.getPosition());
			Case a;
			boolean recul =false;
			for(int i = 0; i <nb; i++) {
				if (recul==false) {
					if(li.hasNext()) li.next(); //si il y a _un �l�men,t arp�s on renvoie l'elem suivant et on avance le curseur
					else {
						recul=true;  //sinon on se pr�pare � reculer et on recul  le curseur d'un cran
						li.previous();
					}
				}
				else li.previous();// on recule 
			}
			
			if (recul) {		//on r�cup�re les info de la case et on repositionne le curseur
				a =li.next();
				li.previous();
			}
			else {
				a =li.previous(); // idem
				li.next();
			}
			
			joueur.setPosition(a.getIdCase());  //on r�cup�re la position de la case et on met � jour celle du joueur
			return a;
		}
		
		private Case deplacementArri�re ( Joueur joueur) {
			
			int nb= joueur.getJetDes();
			if ((nb<-13||nb>63||nb==0||nb==1||nb==-1)) throw new IllegalArgumentException("id pas dans l'interval absolu des d�s");
			ListIterator<Case> li = listeCase.listIterator(joueur.getPosition());
			Case a;
			
			for(int i = 0; i >nb; i--) {
				if(li.hasPrevious()) li.previous(); //si il y a _un �l�men,t avant on renvoie l'elem pr�c�dent et on recul le curseur
													//si on peut plus reculer on est sur la premi�re case
			}	
			a =li.next();
			li.previous();//on r�cup�re les info de la case et on repositionne le curseur 
			joueur.setPosition(a.getIdCase());  //on r�cup�re la position de la case et on met � jour celle du joueur
			return a;
		
		}
		
		public void actionRegles(Case Case , Joueur joueur) {
			
			int id= Case.getIdRegle();
			if ((id<1)||(id>63)) throw new IllegalArgumentException("id pas dans l'interval des r�gles");
			int idTest;
			if	(id!=63) {
				if (id%9==0) idTest=9;  //test pour les cases de l'oie qui ont multiple de 9 comme position
				else idTest=id;
			}
			else idTest=id;
			
			switch(idTest)
			      {
					 case 6:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" ");	 
					   System.out.println("avance case 12");
					   joueur.setPosition(12);
					   System.out.println("tu est sur la case "+joueur.getPosition()+" ");
					   break;
					   
					 case 9:
					   System.out.println("tu est case "+joueur.getPosition()+" "); 
					   System.out.println("avance � nouveau du montant du jet");
					   actionRegles(deplacement (joueur),joueur);
					   break;
					   
					 case 19:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
					   System.out.println("bloqu� un tour ");
					   joueur.setBloque(1);
					   break;
					   
					 case 31:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" ");
					   System.out.println("tomb� dans le puits tu devras faire un 6 pour sortir ");
					   joueur.setBloque(1);
				       break;
				       
					 case 42:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" ");
				       System.out.println("tu es dans le labyrinthe recule de 12 cases  ");
				       joueur.setPosition((joueur.getPosition())-12);    
				       break;
					 case 52:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
					   System.out.println("bloqu� deux tour ");
					   joueur.setBloque(2);
					   break;  
					   
					 case 58:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
					   System.out.println("tu retourne � la premi�re case ");
					   joueur.setPosition(1);
					   break;
					   
					 case 63:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
					   System.out.println("tu as gagn� ");
					   joueur.setVictoire(true);
					   break;
					   
					 default:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" ");
					   System.out.println("fin normale de tour ");
					   
			      }
		}
		
		
		public boolean Tour() {
			boolean victoire=false;
			ListIterator<Joueur> li = listeJoueur.listIterator(); 
			Joueur joueur ; 
			while(li.hasNext()) {      //on it�re sur chaques joueur pour leurs tours de jeu
				joueur = li.next();
			
				System.out.println("d�but du tour  du joueur "+ joueur.getId()+" / "+ joueur.getNom());
																										//gestion des sauts de tours/attente
				int tourBloque=joueur.getBloque();
				if (tourBloque<0) throw new IllegalArgumentException("nb tour bloqu�s <0 ");
				if (tourBloque>0) {
					
					switch(joueur.getPosition())
				      {
						 case 19:
						   System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
						   System.out.println("tu bougeras au prochain tour ");
						   joueur.setBloque(0);
						   break;
						   
						 case 31:
						   System.out.println("tu est sur la case "+joueur.getPosition()+" ");
						   System.out.println("tu est tomb� dans le puits tu dois faire un 6 pour sortir ");
						   Random r1 = new Random();
						   Random r2 = new Random();
						   int valeur1 = 1 + r1.nextInt(6); // d� de 1 � 6
						   int valeur2 = 1 + r2.nextInt(6);
						   if (valeur1==6) joueur.setBloque(0);
						   if (valeur2==6) joueur.setBloque(0);
						   System.out.println("tu est libre");
					       break;
						   
						 case 52:
						    System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
						    joueur.setBloque(joueur.getBloque()-1); //on retire un tour d'attente
							System.out.println("tu est bloqu� encore " + joueur.getBloque() +  " tour");
							
							break;  
						 
				      }
					
				}
				else {															
					Random r = new Random();
					int valeur = 2 + r.nextInt(11); // lanc� de 2 d�s � six faces
					joueur.setJetdes(valeur);
					Case Case = deplacement(joueur);
					actionRegles(Case,joueur);//on d�place le joueur et on applique l'effet de la case
					int tailleListeJoueur=listeJoueur.size();
					if (tailleListeJoueur == 0)  throw new IllegalArgumentException("la listeJoueur est  vide");	
						for(int i = 0; i < tailleListeJoueur; i++) { //test de position car chaque case doit contenir au plus 1 joueur et d'apr�s les r�gles on doit intervertir les places
							Joueur joueur2=listeJoueur.get(i);
							if ((joueur.getId()!= joueur2.getId()) && (joueur.getPosition()==joueur2.getPosition()) && (joueur.getPosition()!=1)) {
									System.out.println("le joueur "+ joueur.getId() + "/" +joueur.getNom()+" est arriv� sur la case occup�e par le joueur "+joueur2.getId() + "/" +joueur2.getNom() );
									joueur2.setPosition(joueur.getPosition()- joueur.getJetDes()); //si le joueur arrive sur une case occup�e par le joueur 2, le joueur 2 vas sur la case initiale du joueur 1
									System.out.println("le joueur "+ joueur2.getId() + "/" +joueur2.getNom()+" recule case  "+joueur2.getPosition());
									Case Case2 =listeCase.get(joueur2.getPosition()-1);
									actionRegles(Case2,joueur2);									//si le joueur 2 arrive sur une case � effet on apllique l'effet
									
						}
					}
		
				}
			}
			ListIterator<Joueur> li2 = listeJoueur.listIterator(); 
			Joueur joueurtest ; 
			while(li2.hasNext()) {      //on it�re sur chaque joueur pour leurs tours de jeu
				joueurtest = li2.next();
				if (joueurtest.getVictoire()) {
					victoire=true;
					System.out.println(" joueur "+ joueurtest.getId()+" / "+ joueurtest.getNom()+ " est vainqueur");
				}
			}
			return victoire;
		}
}
