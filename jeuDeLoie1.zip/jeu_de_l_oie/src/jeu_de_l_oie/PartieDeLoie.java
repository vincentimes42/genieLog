package jeu_de_l_oie;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.Scanner;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;


public class PartieDeLoie  extends JFrame  implements ActionListener{
	
	private JLabel choix_plateau = new JLabel("Choisissez votre type de plateau :");
	private JLabel jeuDeLoie = new JLabel("jeu de L'oie :");
	private JButton Classique = new JButton("Classique");
	private JButton Aleatoire = new JButton("Aleatoire");
	private JButton De1 = new JButton("d� 1");
	private JButton De2 = new JButton("d� 2");
	private boolean waitDe1 = true;
	private boolean waitDe2 = true;
	private plateau P= new plateau();
	
	
	public void ChoixPlateau(){
		this.setTitle("Choix Plateau");
		this.setSize(500, 500);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
	    
	    JPanel typePlateau = new JPanel();
	    typePlateau.setLayout(new GridLayout(2, 1));
	    typePlateau.add(Classique);
	    typePlateau.add(Aleatoire);
	    
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(choix_plateau, BorderLayout.NORTH);
	    this.getContentPane().add(typePlateau, BorderLayout.CENTER);
	    
	    Classique.setBackground(Color.GREEN);
	    Aleatoire.setBackground(Color.BLUE);
	    
	    Classique.addActionListener(this);
	    Aleatoire.addActionListener(this);
	    
	    this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0){
		
		JButton btn = (JButton) arg0.getSource();
		if(btn.getText()=="Classique"){
			this.dispose();
			AffichagePlateau(1);
		    
		}
		else if(btn.getText()=="Aleatoire"){
			this.dispose();
			AffichagePlateau(2);
		   
		}	
		else if(btn.getText()=="d� 1") { waitDe1=false;}
		
		else if(btn.getText()=="d� 2") {waitDe2=false; }
	}
	
	
	public void AffichagePlateau(int typePlateau) {
		this.setTitle("jeu de l'oie");
		this.setSize(900, 900);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
	    
	    JPanel Plateau = new JPanel();
	    Plateau.setLayout(new GridLayout(8,8,5,1));
	    if (typePlateau==1) P.creerPlateauClassique();
	    if (typePlateau==2)P.creerPlateauAleatoire();
	    ListIterator<Case> lic = P.getListeCase().listIterator(); //cr�ation boutons cases et ajout au panel Plateau
		Case Case ; 
		while(lic.hasNext()) {      //on it�re sur chaque case de la  liste
			Case= lic.next();
		    Plateau.add(affichageCase(Case));
		}
	    
		JPanel PanneauInfo = new JPanel();
	    PanneauInfo.setLayout(new GridLayout(5, 3));
	    PanneauInfo.add(De1);
	    PanneauInfo.add(De2);
	    
		
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(jeuDeLoie, BorderLayout.NORTH);
	    this.getContentPane().add(Plateau, BorderLayout.CENTER);
	    this.getContentPane().add(PanneauInfo, BorderLayout.EAST);
	    
	    
	    
	    De1.addActionListener(this);
	    De2.addActionListener(this);
	    
	    this.setVisible(true);
		}
		
		public JButton affichageCase(Case Case) {
			JButton button = new JButton(); 
			int id= Case.getIdRegle();
			if ((id<1)||(id>63)) throw new IllegalArgumentException("idCase pas dans l'interval des r�gles");
			int idTest;
			if	(id!=63) {
				if (id%9==0) idTest=9;  //test pour les cases de l'oie qui ont multiple de 9 comme position
				else idTest=id;
			}
			else idTest=id;
			
			switch(idTest)
			      {
					 case 6:
							button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/pont.jpg")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
					   break;
					   
					 case 9:
						 	button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/oie.jpg")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
					   break;
					   
					 case 19:
						 	button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/hotel.jpg")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
					   break;
					   
					 case 31:
						 button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/puis.jpg")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
				       break;
				       
					 case 42:
						 	button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/maze.png")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);    
				       break;
					 case 52:
						 	button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/prison.png")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
					   break;  
					   
					 case 58:
						 	button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/crane.png")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
					   break;
					   
					 case 63:
						 	button.setText(""+Case.getIdCase()); 
							button.setIcon(new ImageIcon("jeu_de_l_oie/win.png")); 
							button.setVerticalTextPosition(SwingConstants.CENTER); 
							button.setHorizontalTextPosition(SwingConstants.CENTER);
					   break;
					   
					 default:
						 button.setText(""+Case.getIdCase());
					   
			      }
			return button;
		}
	
	public  boolean Tour() {
		
		int tailleListeJoueur=P.getListeJoueur().size();
		if (tailleListeJoueur == 0)  throw new IllegalArgumentException("la listeJoueur est  vide");
		boolean victoire=false;
		
		ListIterator<Joueur> li = P.getListeJoueur().listIterator();  //on it�re sur chaques joueur pour leurs tours de jeu
		Joueur joueur ; 
		while(li.hasNext()) {     
			joueur = li.next();
			System.out.println("d�but du tour  du joueur "+ joueur.getId()+" / "+ joueur.getNom());
												//gestion des sauts de tours/attente
			int tourBloque=joueur.getBloque();
			if (tourBloque<0) throw new IllegalArgumentException("nb tour bloqu�s <0 ");
			if (tourBloque>0) {
				switch(joueur.getPosition())
			      {
					 case 19:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
					   System.out.println("tu bougeras au prochain tour ");
					   joueur.setBloque(0);
					   break;
					   
					 case 31:
					   System.out.println("tu est sur la case "+joueur.getPosition()+" ");
					   System.out.println("tu est tomb� dans le puits tu dois faire un 6 pour sortir ");
					   Random r1 = new Random();				
					   System.out.println("Le joueur "+ joueur.getId()+" / "+joueur.getNom()+ " doit lancer le d� 1");
					   while(waitDe1 == true){
							//attente jusqu'a ce que le joueur clic sur le bouton d� 1
					   }						
					   int valeur1 = 1 + r1.nextInt(6); // d� de 1 � 6 					
					   Random r2 = new Random();
					   System.out.println("Le joueur "+ joueur.getId()+" / "+joueur.getNom()+ " doit lancer le d� 2");
					   while(waitDe2 == true){
							//attente jusqu'a ce que le joueur clic sur le bouton d� 2
					   }						
					   int valeur2 = 1 + r2.nextInt(6);	
					   System.out.println("D� 1 : "+ valeur1+ "     D� 2:  "+ valeur2);
					   if (valeur1==6) joueur.setBloque(0);
					   if (valeur2==6) joueur.setBloque(0);
					   System.out.println("tu est libre");
					   waitDe1 = true;  // on remet la variable waitDe1 � vrai pour un prochain test
					   waitDe2 = true;	// on remet la variable waitDe2 � vrai pour un prochain test
				       break;
					   
					 case 52:
					    System.out.println("tu est sur la case "+joueur.getPosition()+" "); 
					    joueur.setBloque(joueur.getBloque()-1); //on retire un tour d'attente
						System.out.println("tu est bloqu� encore " + joueur.getBloque() +  " tour");
						
						break;  
					 
			      }
				
			}
			else {						// d�but d'un tour normal									
				
				Random r1 = new Random();
				System.out.println("Le joueur "+ joueur.getId()+" / "+joueur.getNom()+ " doit lancer le d� 2");
				while(waitDe1 == true){
					//attente jusqu'a ce que le joueur clic sur le bouton d� 1
			    }						
				int valeur1 = 1 + r1.nextInt(6); // d� de 1 � 6 
				Random r2 = new Random();
				System.out.println("Le joueur "+ joueur.getId()+" / "+joueur.getNom()+ " doit lancer le d� 2");
				while(waitDe2 == true){
					//attente jusqu'a ce que le joueur clic sur le bouton d� 2
			    }						
				int valeur2 = 1 + r2.nextInt(6);	
				int valeur=valeur1+ valeur2;
				System.out.println("D� 1 : "+ valeur1+ "     D� 2:  "+ valeur2 +  "    tot: " + valeur );
				waitDe1 = true;  // on remet laz variable waitDe1 � vrai pour un prochain test
				waitDe2 = true;	// on remet laz variable waitDe2 � vrai pour un prochain test
				joueur.setJetdes(valeur);
				
				Case Case = P.deplacement(joueur);
				P.actionRegles(Case,joueur);//on d�place le joueur et on applique l'effet de la case
				
					
					for(int i = 0; i < tailleListeJoueur; i++) { //test de position car chaque case doit contenir au plus 1 joueur et d'apr�s les r�gles on doit intervertir les places
						Joueur joueur2=P.getListeJoueur().get(i);
						if ((joueur.getId()!= joueur2.getId()) && (joueur.getPosition()==joueur2.getPosition()) && (joueur.getPosition()!=1)) {
								System.out.println("le joueur "+ joueur.getId() + "/" +joueur.getNom()+" est arriv� sur la case occup�e par le joueur "+joueur2.getId() + "/" +joueur2.getNom() );
								joueur2.setPosition(joueur.getPosition()- joueur.getJetDes()); //si le joueur arrive sur une case occup�e par le joueur 2, le joueur 2 vas sur la case initiale du joueur 1
								System.out.println("le joueur "+ joueur2.getId() + "/" +joueur2.getNom()+" recule case  "+joueur2.getPosition());
								Case Case2 =P.getListeCase().get(joueur2.getPosition()-1);
								P.actionRegles(Case2,joueur2);									//si le joueur 2 arrive sur une case � effet on apllique l'effet
								
					}
				}
	
			
			}
			ListIterator<Joueur> li2 = P.getListeJoueur().listIterator(); 
			Joueur joueurtest ; 
			while(li2.hasNext()) {      //on it�re sur chaque joueur pour leurs tours de jeu
				joueurtest = li2.next();
				if (joueurtest.getVictoire()) {
					victoire=true;
					System.out.println(" joueur "+ joueurtest.getId()+" / "+ joueurtest.getNom()+ " est vainqueur");
				}
			}
			
		}
		return victoire;  //retourne vrai si un joueur � gagn� faux sinon
	}
	//accesseur
	public plateau getPlateau() {
		return this.P;
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
		boolean tour;
		PartieDeLoie partie= new PartieDeLoie();
		partie.ChoixPlateau();
		
		partie.getPlateau().getListeCase(); //recup liste des cases du plateau g�n�r�
		
		List lj = new LinkedList();
		Scanner scan = new Scanner(System.in);
		System.out.println("Veuillez saisir le nombre de joueurs :");
		int nb = scan.nextInt();
		System.out.println(nb+ "joueur(s)");
		for(int i = 0; i< nb ; i++) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Veuillez saisir un nom de joueur :");
			String str = sc.nextLine();
			System.out.println("Vous avez saisi : " + str);
		    lj.add(str);
		}
		
	    partie.getPlateau().creerListejoueur(lj);
		tour=false;
		
		while (tour==false){
			tour=partie.Tour();
		}
	}
}