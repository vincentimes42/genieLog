

public class Case {

	private int idCase; //position de la case
	private int idRegle; // r�gle a appliquer pour un plateau classique id case = r�gle � respecter
	
	
	
	//constructeur
		
	public Case (int id){
		this.idCase =id;
		this.idRegle =id;
	}
	
	public Case (int idCase, int idRegle){
		this.idCase =idCase;
		this.idRegle =idRegle;
	}
	
	//accesseur
		
		public void setIdCase(int id){
			this.idCase= id;
		}
		
		public void setIdRegle(int idRegle){
			this.idRegle= idRegle;
		}
		
		public int getIdCase(){
			return idCase;
		}
		
		public int getIdRegle(){
			return idRegle;
		}
}
