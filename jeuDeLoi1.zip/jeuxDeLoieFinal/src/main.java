
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

 class main  {
	public static void  main (String[] args) {
		boolean Tour;
		plateau P= new plateau();
		P.creerPlateauClassique();
		P.getListeCase();
		List lj = new LinkedList();
		/*
		Scanner scan = new Scanner(System.in);
		System.out.println("Veuillez saisir le nombre de joueurs :");
		int nb = scan.nextInt();
		System.out.println(nb+ "joueur(s)");
		for(int i = 0; i< nb ; i++) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Veuillez saisir un nom de joueur :");
			String str = sc.nextLine();
			System.out.println("Vous avez saisi : " + str);
		    lj.add(str);
		}*/
	    lj.add("vincent");
	    lj.add("toto");
		P.creerListejoueur(lj);
		
		Tour=false;
		while (Tour==false){
			Tour=P.Tour();
			System.out.println("----------------------------------------------------");
			
		}
		
		/*P.getListeJoueur().get(0).setJetdes(3);
		System.out.println("jet joueur" +(-1)*P.getListeJoueur().get(0).getJetDes());
		*/
	}
}
