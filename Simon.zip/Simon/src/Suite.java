import java.util.ArrayList;

public class Suite {
	private ArrayList<String> caseOrdi;
	private ArrayList<String> couleur;
	
	public Suite(){
		this.caseOrdi = new ArrayList<String>();
		this.couleur = new ArrayList<String>();

		couleur.add("Rouge");
		couleur.add("Vert");
		couleur.add("Bleu");
		couleur.add("Jaune");
	}
	
	public void ajoutElementListe(int size){
		int min=0,max=4;
		if(caseOrdi.size()==0){
			for(int i=0; i<4; i++){
				caseOrdi.add(couleur.get(min+(int)(Math.random()*((max - min)))));
			}
		}else{
			caseOrdi.add(couleur.get(min+(int)(Math.random()*((max - min)))));
		}
	}
	
	public String compare(ArrayList<String> list){
		boolean rep = false;
		String reponse="";
		for(int i=0; i<caseOrdi.size(); i++){
			if(caseOrdi.equals(list)){
				rep = true;
			}
		}
		if(rep==true){
			reponse="Suite exacte";
			ajoutElementListe(caseOrdi.size());
		}else{
			reponse="Echec";
			caseOrdi.removeAll(caseOrdi);
		}
		return reponse;
	}

	public ArrayList<String> getCaseOrdi(){
		return this.caseOrdi;
	}
	
	public ArrayList<String> getCouleur(){
		return this.couleur;
	}
}
