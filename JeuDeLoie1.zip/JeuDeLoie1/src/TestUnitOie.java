

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JButton;
import org.junit.Test;



public class TestUnitOie {
		//Joueur joueur = new  joueur(0, martin);
	/*@Test
	public void testAjoutElementListe() {
		SuiteEtPaire paire =new SuiteEtPaire();
		paire.ajoutElementListe();
	    assertEquals(8, paire.getCaseOrdi().size());
	}*/
	
	/*
	 @Test
	  public void toRomanKnownValues() {
	    for (Map.Entry<Integer, String> v : KNOWN_VALUES.entrySet()) {
	      assertThat(RomanNumber.valueOf(v.getValue()).intValue(), is(v.getKey()));
	    }
	  }

	          @Test(expected = IllegalArgumentException.class)
	          public void toRomanZero() {
	                  RomanNumber.valueOf(0);
	          }
				*/
	       

	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_creerPlateauClassique() { // test condition listeCase vide � 
	        	Plateau P =new Plateau();
	        	P.creerPlateauClassique();
	        	P.creerPlateauClassique();
	        	
	        	
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_creerPlateauAleatoire() {  // test condition listeCase vide
		        	Plateau P =new Plateau();
		        	P.creerPlateauAleatoire();
		        	P.creerPlateauAleatoire();
	        }
	        
	        
	        @Test(expected = IllegalArgumentException.class)  //test condition cr�ation liste joueur
	        public void Test_listeParamVide_creerListejoueur(){
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	    		P.creerListejoueur(lj);;
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_listeJoueurNonVide_creerListejoueur(){
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	    		P.creerListejoueur(lj);
	    		P.creerListejoueur(lj);
	        }
	        
	        @Test(expected = IllegalArgumentException.class) //tests d�placement plus gd que 63  (nb case Plateau)
	        public void Test_AvantSupNbcases_deplacement(){
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setJetdes(64);
	    		P.deplacement(P.getListeJoueur().get(0));
	        }
	        
	        @Test(expected = IllegalArgumentException.class) //tests d�placement plus gd que 63  (nb case Plateau)
	        public void Test_ReculSupnbcases_deplacement(){
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setJetdes(-64);
	    		P.deplacement(P.getListeJoueur().get(0));
	        }
	        
	        @Test(expected = IllegalArgumentException.class) //tests d�placement plus gd que 63  (nb case Plateau)
	        public void Test_Position_deplacement(){
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setPosition(-2);
	    		P.getListeJoueur().get(0).setJetdes(10);
	    		P.deplacement(P.getListeJoueur().get(0));
	        }
	        
	        @Test 				//tests d�placement plus gd que la posityiopn du joueur (nb case Plateau) pour v�rifier que on tombe sur la premi�re case
	        public void Test_Recul_deplacement(){
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setPosition(10);
	    		P.getListeJoueur().get(0).setJetdes(-50);
	    		assertEquals(P.getListeCase().get(0).getIdCase(),P.deplacement(P.getListeJoueur().get(0)).getIdCase());
	        }
	        
	        @Test 				
	        public void Test_AvanceRecul_deplacement(){ //ici on teste le recul qui se produit quand un jet de d�s qui fait d�passer la derni�re case. 
	        	Plateau P =new Plateau();				//ici le joueur est sur la case 62 il fait un jet de d� � 2 et doit donc � att�rir sur la case 62 apr�s d�pacement
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setPosition(62);
	    		P.getListeJoueur().get(0).setJetdes(2);
	    		assertEquals(P.getListeCase().get(61).getIdCase(),P.deplacement(P.getListeJoueur().get(0)).getIdCase()); //on teste avec la case 62 (num�rotation de 1 � 63) qui correspond � l'element 61 (num�rotation de 0 � 62) de la liste
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_moinsUn_deplacement(){  // test d�placement moins -1  
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setJetdes(-1);
	    		P.deplacement(P.getListeJoueur().get(0));
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_Un_deplacement(){  // test d�plcaement moins 1 (valeur impossible avec plusieur d�s) 
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerPlateauClassique();
	    		P.creerListejoueur(lj);
	    		P.getListeJoueur().get(0).setJetdes(1);
	    		P.deplacement(P.getListeJoueur().get(0));
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_inferieurUn_actionR�gles(){  // test ActionR�gle avec id incorrecte -1 
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerListejoueur(lj);
	        	Case Case =new Case(-1);
	    		P.actionRegles(Case,P.getListeJoueur().get(0));
	    		
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_listeVideJoueur_CheckConditionTour(){  //on v�rifie que la liste est pas vide
	        	Plateau P =new Plateau();
	        	P.creerPlateauClassique();
	    		P.CheckConditionTour();
	        }
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_listeVideCase_CheckConditionTour(){   //on v�rifie que la liste est pas vide
	        	Plateau P =new Plateau();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerListejoueur(lj);
	    		P.CheckConditionTour();
	        }
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_CasesID_CheckConditionTour(){   //on v�rifie si pls cases on le m�me Id
	        	Plateau P =new Plateau();
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	P.creerListejoueur(lj);
	        	P.getListeCase().get(1).setIdCase(1);
	    		P.CheckConditionTour();
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_JoueurID_CheckConditionTour(){  //on v�rifie si pls Joueurs on le m�me Id
	        	Plateau P =new Plateau();
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	lj.add("toto2");
	        	P.creerListejoueur(lj);
	        	P.getListeJoueur().get(1).setId(0);
	    		P.CheckConditionTour();
	        }
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_VictoireJoueurAvantTour_CheckConditionTour() {  //on v�rifie qu'un joueur n'est pas gagnant avant d'avoir jou� son tour (= triche ?)
	        	Plateau P =new Plateau();
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	lj.add("toto2");
	        	P.creerListejoueur(lj);
	        	P.getListeJoueur().get(1).setVictoire(true);
	        	P.CheckConditionTour();
	        }
	        
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_Case1_echangePlaceSure() {  // test d'�change de place pour des joueurs sur la case 1
	        	Plateau P =new Plateau();		
	        									
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	lj.add("toto2");
	        	P.creerListejoueur(lj);
	        	P.echangePlaceSure(P.getListeJoueur().get(0),P.getListeJoueur().get(1));
	        	
	        }	
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_Memejoueur_echangePlaceSure() {  // test d'�change de place pour le m�me joueur
	        	Plateau P =new Plateau();		
	        									
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	lj.add("toto2");
	        	P.creerListejoueur(lj);
	        	P.echangePlaceSure(P.getListeJoueur().get(0),P.getListeJoueur().get(0));
	        	
	        }	
	        
	        @Test(expected = IllegalArgumentException.class)
	        public void Test_DifPosition_echangePlaceSure() {  // test d'�change de place pour des joueurs avec des positions diff�rentes.
	        	Plateau P =new Plateau();						
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	lj.add("toto2");
	        	P.creerListejoueur(lj);
	        	P.getListeJoueur().get(0).setPosition(2);
	        	P.getListeJoueur().get(1).setPosition(3);
	        	P.echangePlaceSure(P.getListeJoueur().get(0),P.getListeJoueur().get(1));
	        	
	        }
	        
	        @Test
	        public void Test_Blocage_echangePlaceSure() {  // test d'�change de place pour des joueurs sur la m�me case mais celle est bloquante donc il faut d�bloquer le joueur 2
	        	Plateau P =new Plateau();				// la fonction �change doit donc tester le satut du joueur qui est d�plac�.
	        	P.creerPlateauClassique();
	        	List lj = new LinkedList();
	        	lj.add("toto");
	        	lj.add("toto2");
	        	P.creerListejoueur(lj);
	        	P.getListeJoueur().get(0).setPosition(10);
	        	P.getListeJoueur().get(1).setPosition(10);
	        	P.getListeJoueur().get(0).setJetdes(4);
	        	P.getListeJoueur().get(1).setJetdes(2);
	        	P.echangePlaceSure(P.getListeJoueur().get(0),P.getListeJoueur().get(1));
	        	assertEquals(0,P.getListeJoueur().get(1).getBloque());
	        }

	
}
