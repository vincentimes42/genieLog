package ChoixJeux;

import java.util.LinkedList;
import java.util.Scanner;

public class PlayJeuDeLoie implements Runnable {

	public void run(){
		boolean Tour;
		Plateau P= new Plateau();
		P.creerPlateauClassique();
		P.getListeCase();
		LinkedList lj = new LinkedList();
		Scanner scan = new Scanner(System.in);
		System.out.println("Veuillez saisir le nombre de joueurs : ");
		int nb = scan.nextInt();
		System.out.println(nb+ " joueur(s)");
		for(int i = 0; i< nb ; i++) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Veuillez saisir un nom de joueur :");
			String str = sc.nextLine();
			System.out.println("Vous avez saisi : " + str);
		    lj.add(str);
		}
		P.creerListejoueur(lj);
		Tour=false;
		while (Tour==false){
			Tour=P.Tour();
		}
    }

}
