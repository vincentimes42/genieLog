package ChoixJeux;

public class PlayMemory implements Runnable {
	Memory unMemory;
	
	public void run(){
		try {
			unMemory = new Memory();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}
