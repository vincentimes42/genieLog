import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Color;
import java.io.*;

public class Memory  extends JFrame  implements ActionListener{

	private JLabel Memory = new JLabel("Memory");
	private JLabel Resultat = new JLabel("Vous avez :");
	private JButton btn1 = new JButton("");
	private JButton btn2 = new JButton("");
	private JButton btn3 = new JButton("");
	private JButton btn4 = new JButton("");
	private JButton btn5 = new JButton("");
	private JButton btn6 = new JButton("");
	private JButton btn7 = new JButton("");
	private JButton btn8 = new JButton("");
	
	private ArrayList<JButton> button;
	private ArrayList<JButton> compareBout;
	private Paire unePaire;
	private boolean attente =false;
	private int t=0;
	
	public Memory() throws InterruptedException{
		unePaire = new Paire();
		unePaire.ajoutElementListe();
		
		button = new ArrayList<JButton>();
		compareBout = new ArrayList<JButton>();
		Memory.setHorizontalAlignment(SwingConstants.CENTER);
		Resultat.setHorizontalAlignment(SwingConstants.CENTER);
	    this.setTitle("Simon");
	    this.setSize(500, 500);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);

	    JPanel simon = new JPanel();
	    simon.setLayout(new GridLayout(4, 4));
	    simon.add(btn1);
	    simon.add(btn2);
	    simon.add(btn3);
	    simon.add(btn4);
	    simon.add(btn5);
	    simon.add(btn6);
	    simon.add(btn7);
	    simon.add(btn8);
	    
	    this.setLayout(new BorderLayout());
	    this.getContentPane().add(Memory, BorderLayout.NORTH);
	    this.getContentPane().add(simon, BorderLayout.CENTER);
	    this.getContentPane().add(Resultat, BorderLayout.SOUTH);
		
	    button.add(btn1);
	    button.add(btn2);
	    button.add(btn3);
	    button.add(btn4);
	    button.add(btn5);
	    button.add(btn6);
	    button.add(btn7);
	    button.add(btn8);
	    
    	btn1.addActionListener(this);
	    btn2.addActionListener(this);
	    btn3.addActionListener(this);
	    btn4.addActionListener(this);
    	btn5.addActionListener(this);
	    btn6.addActionListener(this);
	    btn7.addActionListener(this);
	    btn8.addActionListener(this);
	    this.setVisible(true);
	    
	    for (int i = 1; i >= 0; i--){
	    	btnAfficher(true);
	    	Thread.sleep(1500);
		}
	    btnAfficher(false);
	    
		String reponse = "";
		while(t<4){
		    Thread.sleep(3000);
			if(compareBout.size()==2){
				attente=unePaire.compare(compareBout);
				if(attente==true){
					reponse="Suite exacte";
					compareBout.get(0).setEnabled(false);
					compareBout.get(1).setEnabled(false);
					t++;
				}else{
					reponse="Echec, reessayer";
					compareBout.get(0).setText("");
					compareBout.get(1).setText("");
				}
				compareBout.removeAll(compareBout);
			}
			Resultat.setText("Vous avez : "+ reponse);
		}
	    
		if(t==4){
			Resultat.setText("Victoire");
			Thread.sleep(3000);
		    this.dispose();
		}else{

			Resultat.setText("Perdu");
			btn1.setEnabled(false);
			btn2.setEnabled(false);
			btn3.setEnabled(false);
			btn4.setEnabled(false);
			btn5.setEnabled(false);
			btn6.setEnabled(false);
			btn7.setEnabled(false);
			btn8.setEnabled(false);
			Thread.sleep(3000);
		    this.dispose();
		}
	}

	public void btnAfficher(boolean affiche){
		if(affiche){
			btn1.setText(unePaire.getCaseOrdi().get(0));
		    btn2.setText(unePaire.getCaseOrdi().get(1));
		    btn3.setText(unePaire.getCaseOrdi().get(2));
		    btn4.setText(unePaire.getCaseOrdi().get(3));
	    	btn5.setText(unePaire.getCaseOrdi().get(4));
		    btn6.setText(unePaire.getCaseOrdi().get(5));
		    btn7.setText(unePaire.getCaseOrdi().get(6));
		    btn8.setText(unePaire.getCaseOrdi().get(7));
		}else{
			btn1.setText("");
		    btn2.setText("");
		    btn3.setText("");
		    btn4.setText("");
	    	btn5.setText("");
		    btn6.setText("");
		    btn7.setText("");
		    btn8.setText("");
		}
	}
	
	public void actionPerformed(ActionEvent arg0){
		JButton btn = (JButton) arg0.getSource();
		int num=button.indexOf(btn);
		btn.setText(unePaire.getCaseOrdi().get(num));
			
		compareBout.add(btn);
		
		
	}
	
	public static void main(String[] args) throws InterruptedException {
		Memory memoire = new Memory();

	}

}
